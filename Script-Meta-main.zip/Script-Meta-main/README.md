# Script-Meta
Script Meta Punya ROY-ID , Belum Di Oprek Sedikit Pun
